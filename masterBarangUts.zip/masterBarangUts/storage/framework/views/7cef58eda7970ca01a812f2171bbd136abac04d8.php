<div class="container-sm my-5">
    <div class="row justify-content-center">
        <div class="p-5 bg-light rounded-3 col-xl-4 border">
            <div class="mb-3 text-center">
                <i class="bi-person-circle fs-1"></i>
                <h4 class="text-warning">Biodata</h4>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-12 mb-3">
                    <label class="form-label">Nama</label>
                    <h5>Arsy Shifa Nuril Azmi</h5>
                </div>
                <div class="col-md-12 mb-3">
                    <label class="form-label">Tanggal Lahir</label>
                    <h5>06 Juni 2003</h5>
                </div>
                <div class="col-md-12 mb-3">
                    <label  class="form-label">NIM/Kelas</label>
                    <h5>1204220005/IS-05-02</h5>
                </div>
                <div class="col-md-12 mb-3">
                    <label  class="form-label">Program Studi</label>
                    <h5>Sistem Informasi</h5>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\MiniProject\resources\views/default.blade.php ENDPATH**/ ?>